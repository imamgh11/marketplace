<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * RajaOngkir API Key
 * Silakan daftar akun di RajaOngkir.com untuk mendapatkan API Key
 * http://rajaongkir.com/akun/daftar
 */
$config['rajaongkir_api_key'] = "cc7c7bafc8c82c75d30221b70abb34c8";

// Api Key 2
//$config['rajaongkir_api_key'] = "ca9b4fa11b9265180a22a811138d59fc";

/**
 * RajaOngkir account type: starter or basic
 * http://rajaongkir.com/dokumentasi#akun-ringkasan
 * 
 */
$config['rajaongkir_account_type'] = "starter";
